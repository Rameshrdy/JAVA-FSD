import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Camera {
    private String brand;
    private String model;
    private double perDayRent;

    public Camera(String brand, String model, double perDayRent) {
        this.brand = brand;
        this.model = model;
        this.perDayRent = perDayRent;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayRent() {
        return perDayRent;
    }
}

class User {
    private double walletBalance;

    public User(double walletBalance) {
        this.walletBalance = walletBalance;
    }

    public double getWalletBalance() {
        return walletBalance;
    }

    public void setWalletBalance(double walletBalance) {
        this.walletBalance = walletBalance;
    }
}

public class CameraRentalApplication {
    private List<Camera> cameraList;
    private User user;

    public CameraRentalApplication() {
        cameraList = new ArrayList<>();
        user = new User(0.0);
    }

    public void addCamera(Camera camera) {
        cameraList.add(camera);
    }

    public void rentCamera(Camera camera) {
        if (cameraList.contains(camera)) {
            if (user.getWalletBalance() >= camera.getPerDayRent()) {
                user.setWalletBalance(user.getWalletBalance() - camera.getPerDayRent());
                System.out.println("Camera rented successfully!");
            } else {
                System.out.println("Insufficient wallet balance to rent the camera.");
            }
        } else {
            System.out.println("Selected camera is not available for rent.");
        }
    }

    public void depositAmount(double amount) {
        user.setWalletBalance(user.getWalletBalance() + amount);
        System.out.println("Amount deposited successfully!");
    }

    public void viewWalletBalance() {
        System.out.println("Current wallet balance: " + user.getWalletBalance());
    }

    public void displayCameraList() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available for rent.");
        } else {
            System.out.println("Camera List:");
            for (Camera camera : cameraList) {
                System.out.println("Brand: " + camera.getBrand() + " | Model: " + camera.getModel() +
                        " | Per-day Rent: " + camera.getPerDayRent());
            }
        }
    }

    public void showWelcomeScreen() {
        System.out.println("Welcome to RentMyCam.io");
        System.out.println("Developer: [Your Name]");
        System.out.println("----------------------------");
        System.out.println("1. Rent a Camera");
        System.out.println("2. Add Balance to Wallet");
        System.out.println("3. View Wallet Balance");
        System.out.println("4. Exit");
        System.out.println("----------------------------");
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            showWelcomeScreen();
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    displayCameraList();
                    System.out.print("Enter the brand of the camera you want to rent: ");
                    String brand = scanner.nextLine();
                    System.out.print("Enter the model of the camera you want to rent: ");
                    String model = scanner.nextLine();

                    Camera selectedCamera = null;
                    for (Camera camera : cameraList) {
                        if (camera.getBrand().equalsIgnoreCase(brand) && camera.getModel().equalsIgnoreCase(model))
                            if (selectedCamera != null) {
                                rentCamera(selectedCamera);
                            } else {
                                System.out.println("Selected camera is not available for rent.");
                            }
                            break;
                    }

                 case 2:
                            System.out.print("Enter the amount to deposit: ");
                            double amount = scanner.nextDouble();
                            depositAmount(amount);
                            break;

                 case 3:
                            viewWalletBalance();
                            break;

                        case 4:
                            System.out.println("Thank you for using RentMyCam.io. Goodbye!");
                            System.exit(0);
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                            break;
                    }
                }
            }

            public static void main(String[] args) {
                CameraRentalApplication rentalApp = new CameraRentalApplication();

                // Sample data for cameras
                rentalApp.addCamera(new Camera("Canon", "EOS 5D Mark IV", 50.0));
                rentalApp.addCamera(new Camera("Nikon", "D850", 60.0));
                rentalApp.addCamera(new Camera("Sony", "Alpha A7 III", 70.0));

                rentalApp.start();
            }
}