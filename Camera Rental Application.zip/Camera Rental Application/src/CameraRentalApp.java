import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CameraRentalApp {
    private static Scanner scanner = new Scanner(System.in);
    private static List<Camera> cameraList = new ArrayList<>();
    private static double walletBalance = 1723.5;

    public static void main(String[] args) {
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.println("WELCOME TO CAMERA RENTAL APP");
            System.out.println("PLEASE LOGIN TO CONTINUE:");
            System.out.print("USERNAME: ");
            String username = scanner.nextLine();
            System.out.print("PASSWORD: ");
            String password = scanner.nextLine();
            
            // Perform login validation
            if (login(username, password)) {
                loggedIn = true;
                System.out.println("Login successful!\n");
                displayMainMenu();
            } else {
                System.out.println("Invalid username or password. Please try again.\n");
            }
        }
    }

    private static boolean login(String username, String password) {
        return username.equals("admin") && password.equals("admin123");
    }

    private static void displayMainMenu() {
        boolean exit = false;
        while (!exit) {
            System.out.println("1. MY CAMERA");
            System.out.println("2. RENT A CAMERA");
            System.out.println("3. VIEW ALL CAMERAS");
            System.out.println("4. MY WALLET");
            System.out.println("5. EXIT");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    handleMyCamera();
                    break;
                case 2:
                    rentCamera();
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    handleWallet();
                    break;
                case 5:
                    exit = true;
                    System.out.println("Thank you for using the Camera Rental App. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.\n");
            }
        }
    }

    private static void handleMyCamera() {
        boolean backToMenu = false;
        while (!backToMenu) {
            System.out.println("\n1. ADD");
            System.out.println("2. REMOVE");
            System.out.println("3. VIEW MY CAMERAS");
            System.out.println("4. GO TO PREVIOUS MENU");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addCamera();
                    break;
                case 2:
                    removeCamera();
                    break;
                case 3:
                    viewMyCameras();
                    break;
                case 4:
                    backToMenu = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.\n");
            }
        }
    }

    private static void addCamera() {
        System.out.print("ENTER THE CAMERA BRAND: ");
        String brand = scanner.nextLine();
        System.out.print("ENTER THE MODEL: ");
        String model = scanner.nextLine();
        System.out.print("ENTER THE PER DAY PRICE (INR): ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline character

        Camera camera = new Camera(brand, model, price);
        cameraList.add(camera);

        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.\n");
    }

    private static void removeCamera() {
        System.out.println("ENTER THE CAMERA ID TO REMOVE: ");
        int Camera
     // Display camera list
        displayCameraList();

        System.out.print("Enter the camera ID: ");
        int cameraId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        // Find the camera with the given ID
        Camera cameraToRemove = null;
        for (Camera camera1 : cameraList) {
            if (camera1.getId() == cameraId) {
                cameraToRemove = camera1;
                break;
            }
        }

        if (cameraToRemove != null) {
            cameraList.remove(cameraToRemove);
            System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.\n");
        } else {
            System.out.println("Invalid camera ID. Please try again.\n");
        }
    }

    private static void viewAllCameras() {
        displayCameraList();
    }

    private static void viewMyCameras() {
        if (cameraList.isEmpty()) {
            System.out.println("You don't have any cameras in your list.\n");
        } else {
            displayCameraList();
        }
    }

    private static void displayCameraList() {
        System.out.println("CAMERA ID\tSTATUS\t\tBRAND\t\tMODEL\t\tPRICE (PER DAY)");
        for (Camera camera : cameraList) {
            System.out.printf("%-10d\t%-15s\t%-15s\t%-15s\t%.2f%n",
                    camera.getId(), camera.getStatus(), camera.getBrand(), camera.getModel(), camera.getPrice());
        }
        System.out.println();
    }

    private static void handleWallet() {
        System.out.println("YOUR CURRENT WALLET BALANCE IS INR. " + walletBalance);
        System.out.print("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET? (1.YES 2.NO): ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (choice == 1) {
            System.out.print("ENTER THE AMOUNT (INR): ");
            double depositAmount = scanner.nextDouble();
            scanner.nextLine(); // Consume newline character

            walletBalance += depositAmount;
            System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE INR. " + walletBalance + "\n");
        }
    }

    private static void rentCamera() {
        System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S)");
        displayCameraList();

        System.out.print("ENTER THE CAMERA ID YOU WANT TO RENT: ");
        int cameraId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        // Find the camera with the given ID
        Camera selectedCamera = null;
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraId) {
                selectedCamera = camera;
                break;
            }
        }

        if (selectedCamera != null) {
            if (selectedCamera.getStatus().equals("Available")) {
                if (selectedCamera.getPrice() <= walletBalance) {
                    selectedCamera.setStatus("Rented");
                    walletBalance -= selectedCamera.getPrice();
                    System.out.println("You have successfully rented the camera.\n");
                } else {
                    System.out.println("ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE.");
                    System.out.println("Please deposit the amount to your wallet.\n");
                }
            } else {
                System.out.println("The selected camera is not available for rent.\n");
            }
        } else {
            System.out.println("Invalid camera ID. Please try again.\n");
        }
    }
}