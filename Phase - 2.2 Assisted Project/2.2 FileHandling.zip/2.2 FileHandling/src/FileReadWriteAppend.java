import java.io.*;

public class FileReadWriteAppend {
    public static void main(String[] args) {
        // specify the file path
        String filePath = "example.txt";

        // write to file
        try {
            FileWriter writer = new FileWriter(filePath);
            writer.write("This is an example.\n");
            writer.close();
            System.out.println("Successfully wrote to file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // read from file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            while (line != null) {
                System.out.println(line);
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // append to file
        try {
            FileWriter writer = new FileWriter(filePath, true);
            writer.write("This is another test.\n");
            writer.close();
            System.out.println("We Successfully appended to file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}