import java.util.Arrays;
import java.util.Scanner;

public class Validation_of_an_email_id {
    public static void main(String[] args) {
        String[] emails = {"ramesh.reddy@practise.com", "yaswanth.reddy@practise.com", "kiran.kumar@example.com", "alicegreen@example.com"};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter email to search:\n ");
        String searchEmail = scanner.nextLine();

        boolean found = Arrays.stream(emails).anyMatch(searchEmail::equalsIgnoreCase);

        if (found) {
            System.out.println("Email found!");
        } else {
            System.out.println("Email not found!");
        }
    }
}